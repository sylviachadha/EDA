/* Union */
/* 1. Union is just pasting results of two
SELECT statements/ stacking results on top
of each other.
2. Syntax-
SELECT col_name FROM table1
UNION
SELECT col_name FROM table2;
 */